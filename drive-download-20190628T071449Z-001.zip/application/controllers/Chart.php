<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chart extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	$chartData=[
          ['jumlah penderita  gizi buruk', 5721],
          ['Jumlah Penderita Gizi Buruk (januari-maret) 2018', 70],
          ['Jumlah Penderita Gizi Buruk Lama dan Baru Tahun 2018', 985],
          ['Jumlah Kasus Meninggal dan Sembuh Penderita Gizi Buruk Tri Wulan Tahun 2018',33],
          ['Jumlah ditemukan dan mendapat perawatan pada Penderita Gizi Buruk Tri Wulan Tahun 2018', 15]
        ];
        $data['PieChartData']=json_encode($chartData);


		$this->load->view('chart');
		$this->load->view('graaafik',$data);

	}
}
