  <html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Tahun', 'jumlah penderita  gizi buruk'],
          ['2013',  964],
          ['2014',  933],
          ['2015',  922],
          ['2016',  982],
          ['2017',  922],
          ['2018',  998]
        ]); 

        var options = {
          title: 'jumlah penderita gizi buruk prov. jawa tengah',
          curveType: 'function',
          legend: { position: 'bottom' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('chart'));

        chart.draw(data, options);
      }



      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart1);

      function drawChart1() {

        var data = google.visualization.arrayToDataTable([
          ['Nama Kota/kab', 'jumlah'],
          ['kab.wonosobo',    17],
          ['kab. banjarnegara',      13],
          ['kab.sukoharjo',  19],
          ['kota magelang', 18],
          ['kota salatiga',    3]
        ]);

        var options = {
          title: 'Jumlah Penderita Gizi Buruk (januari-maret) 2018'
        };

        var chart = new google.charts.Bar(document.getElementById('chart1'));

        chart.draw(data,google.charts.Bar.convertOptions(options));
      }



     google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart2);

      function drawChart2() {

        var data = google.visualization.arrayToDataTable([
          ['Nama Kota/kab', 'penderita Lama', 'pederita baru'],
          ['kab.wonosobo',    9, 337],
          ['kab. banjarnegara',      12, 323],
          ['kab.sukoharjo',  116,92],
          ['kota magelang', 26, 32],
          ['kota salatiga',   12,26]
        ]);

        var options = {
          title: 'Jumlah Penderita Gizi Buruk Lama dan Baru Tahun 2018'
        };

        var chart = new google.charts.Bar(document.getElementById('chart2'));

        chart.draw(data,google.charts.Bar.convertOptions(options));
      }



      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart3);

      function drawChart3() {

        var data = google.visualization.arrayToDataTable([
          ['Nama Kota/kab', 'Meninggal', 'Sembuh'],
          ['kab.wonosobo',    0, 12],
          ['kab. banjarnegara',      0, 0],
          ['kab.sukoharjo',  0,4],
          ['kota magelang', 0, 1],
          ['kota salatiga',   2,14]
        ]);

        var options = {
          title: 'Jumlah Kasus Meninggal dan Sembuh Penderita Gizi Buruk Tri Wulan Tahun 2018'
        };

        var chart = new google.charts.Bar(document.getElementById('chart3'));

        chart.draw(data,google.charts.Bar.convertOptions(options));
      }



      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart4);

      function drawChart4() {

        var data = google.visualization.arrayToDataTable([
          ['Nama Kota/kab', 'Jumlah ditemukan', 'Jumlah mendapat perawatan'],
          ['kab.wonosobo',    32, 32],
          ['kab. banjarnegara',      11, 11],
          ['kab.sukoharjo',  15,15],
          ['kota magelang', 11, 11],
          ['kota salatiga',   ,8]
        ]);

        var options = {
          title: 'Jumlah ditemukan dan mendapat perawatan pada Penderita Gizi Buruk Tri Wulan Tahun 2018'
        };
        

        var chart = new google.charts.Bar(document.getElementById('chart4'));

        chart.draw(data,google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
    <div id="chart" style="width: 900px; height: 500px"></div>
    <div id="chart1" style="width: 800px; height: 300px"></div>
    <div id="chart2" style="width: 800px; height: 300px"></div>
    <div id="chart3" style="width: 800px; height: 300px"></div>
    <div id="chart4" style="width: 800px; height: 300px"></div>
  </body>
</html>